# -*- coding: utf-8 -*-
"""
Created on Tue Oct 20 16:39:31 2020

@author: grant
"""
import os
from math import ceil

os.chdir("C:/Local/sweeps/sweeps/")

# read in the inputs file

with open("input.txt", "r") as infile:
    input_obj = infile.readlines()

print(len(input_obj))

# do 100 loci per file, thats 200 lines.  how many files do we need?

end_num = ceil(len(input_obj)/200)

print(end_num)

# make the folders, with leading zeroes.

os.chdir("C:/Local/sweeps/sweeps/upload/")

"""
for i in range(0, end_num):
    num_string = "{0:03d}".format(i)
    os.mkdir("run" + num_string)

# print the subset of lines in each file
for i in range(0, end_num):
    num_string = "{0:03d}".format(i)
    start_loc = i * 200
    end_loc = (i + 1) * 200

    if end_loc > len(input_obj):
        end_loc = len(input_obj)

    fname = "./run" + num_string + "/input.txt"
    with open(fname, "w", newline="\n") as outfile:
        for line in input_obj[start_loc:end_loc]:
            outfile.write(line)"""


os.chdir("C:/Local/sweeps/sweeps/")

# read in the pbs file
with open("job_001.pbs", "r") as infile:
    pbs_obj = infile.readlines()

for i in range(0, end_num + 1):
    num_string = "{0:03d}".format(i)
    out_lines = pbs_obj.copy()

    out_lines = [i.replace("001", num_string) for i in out_lines]
    out_lines = [i.replace("split -a 10 -l 2 $SNPFILE snp_batch\n",
                           "split -a 10 -l 2 $SNPFILE snp_batch\nsleep 15\n")
                  for i in out_lines]

    fname = "./jobs/job_" + num_string + ".pbs"

    with open(fname, "w", newline="\n") as outfile:
        for line in out_lines:
            outfile.write(line)
